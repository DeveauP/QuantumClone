#!/bin/bash



for param in CNA depth clones  contamination samples  mutations
	do
	echo $param
	echo "cd /data/kdi_prod/project_result/627/02.00/deveau/QC_testing_august_2016;ls scripts/parametered_testing_rerun1.sh;bash scripts/parametered_testing_rerun1.sh -p=$param" | qsub -q batch -o /data/kdi_prod/project_result/627/02.00/deveau/QC_testing_august_2016 -j oe -N QCtest1_$param -l nodes=1:ppn=4,mem=4Gb,walltime=72:00:00
	echo "cd /data/kdi_prod/project_result/627/02.00/deveau/QC_testing_august_2016;ls scripts/parametered_testing_rerun2.sh;bash scripts/parametered_testing_rerun2.sh -p=$param" | qsub -q batch -o /data/kdi_prod/project_result/627/02.00/deveau/QC_testing_august_2016 -j oe -N QCtest2_$param -l nodes=1:ppn=4,mem=4Gb,walltime=72:00:00
	echo "cd /data/kdi_prod/project_result/627/02.00/deveau/QC_testing_august_2016;ls scripts/parametered_testing_rerun3.sh;bash scripts/parametered_testing_rerun3.sh -p=$param" | qsub -q batch -o /data/kdi_prod/project_result/627/02.00/deveau/QC_testing_august_2016 -j oe -N QCtest3_$param -l nodes=1:ppn=4,mem=4Gb,walltime=72:00:00
	if [ $param == "samples" ];then
		echo "cd /data/kdi_prod/project_result/627/02.00/deveau/QC_testing_august_2016;ls scripts/parametered_testing_rerun4.sh;bash scripts/parametered_testing_rerun4.sh -p=$param" | qsub -q batch -o /data/kdi_prod/project_result/627/02.00/deveau/QC_testing_august_2016 -j oe -N QCtest4_$param -l nodes=1:ppn=4,mem=4Gb,walltime=72:00:00
	elif [ $param == "mutations" ];then
		echo "cd /data/kdi_prod/project_result/627/02.00/deveau/QC_testing_august_2016;ls scripts/parametered_testing_rerun4.sh;bash scripts/parametered_testing_rerun4.sh -p=$param" | qsub -q batch -o /data/kdi_prod/project_result/627/02.00/deveau/QC_testing_august_2016 -j oe -N QCtest4_$param -l nodes=1:ppn=4,mem=4Gb,walltime=72:00:00
	fi

done
